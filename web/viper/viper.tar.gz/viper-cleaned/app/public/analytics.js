fetch(document.getElementById("analyticsUrl").innerHTML)
